-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 12, 2022 at 08:51 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `perpustakaan`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_buku` (IN `judul` VARCHAR(100))  NO SQL
SELECT * FROM tbl_buku WHERE tbl_buku.buku_judul LIKE judul$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_member` (IN `nama` VARCHAR(50))  NO SQL
SELECT * FROM tbl_member WHERE tbl_member.member_nama LIKE nama$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_peminjama_1` (IN `idbuku` INT(11))  NO SQL
SELECT * FROM peminjama_1 WHERE peminjama_1.buku_id LIKE idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `cari_pustakawan` (IN `nama` VARCHAR(50))  NO SQL
SELECT * FROM pustakawan WHERE pustakawan.pustakawan_nama LIKE nama$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_buku` (IN `idbuku` INT(11))  NO SQL
DELETE FROM tbl_buku WHERE tbl_buku.buku_id=idbuku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_member` (IN `idmember` INT(11))  NO SQL
DELETE FROM tbl_member WHERE tbl_member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_peminjama_1` (IN `pinjam_id` INT(11))  NO SQL
DELETE FROM peminjama_1 WHERE peminjama_1.pinjam_id=idpinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `hapus_pustakawan` (IN `idpustakawan` INT(11))  NO SQL
DELETE FROM pustakawan WHERE pustakawan.pustakawan_id=idpustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_buku` (IN `buku_judul` VARCHAR(100), IN `buku_tgl_stok` DATE, IN `buku_jumlah` INT(10))  NO SQL
INSERT INTO tbl_buku
(tbl_buku.buku_judul,tbl_buku.buku_tgl_stok,tbl_buku.buku_jumlah)
VALUES(judulbuku,stoktglbuku,jumlahbuku)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_member` (IN `member_nama` VARCHAR(50), IN `member_jenis` ENUM('L','P'), IN `member_tempat` VARCHAR(100), IN `member_tgl` DATE, IN `member_hp` CHAR(13))  NO SQL
INSERT INTO tbl_member
(tbl_member.member_nama,tbl_member.member_jenis_kelamin,tbl_member.member_tempat_lahir,tbl_member.member_tgl_lahir,tbl_member.member_hp)
VALUES(namamember,memberjeniskelamin,membertempatlahir,membertgllahir,memberhp)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_peminjaman_1` (IN `tgl_pinjam` DATE, IN `jumlah_pinjam` INT(3), IN `tgl_kembali` DATE, IN `jumlah_kembali` INT(3), IN `pinjam_lama` INT(2), IN `terlambat_pinjam` INT(2), IN `denda_pinjam` BIGINT(20))  NO SQL
INSERT INTO peminjama_1
(peminjama_1.pinjam_tgl,peminjama_1.pinjam_jumlah,peminjama_1.pinjam_kembali_tgl,peminjama_1.pinjam__kembali_jumlah,peminjama_1.pinjam_lama_pinjam,peminjama_1.pinjam_terlambat,peminjama_1.pinjam_denda)
VALUES(pinjam_tgl,jumlah_pinjam,tgl_kembali,jumlah_kembali,pinjam_lama,terlambat_pinjam,denda_pinjam)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tambah_pustakawan` (IN `pustakawan_nama` VARCHAR(50), IN `pustakawan_jenis` ENUM('L','P'), IN `pustakawan_alamat` TEXT, IN `pustakawan_hp` CHAR(13))  NO SQL
INSERT INTO pustakawan
(pustakawan.pustakawan_nama,pustakawan.pustakawan_jenis,pustakawan.pustakawan_alamat,pustakawan.pustakawan_hp)
VALUES(nama_pustakawan,jenis_pustakawan,alamat_pustakawan,hp_pustakawan)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_buku` ()  NO SQL
SELECT tbl_buku$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_member` ()  NO SQL
SELECT tbl_member$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_peminjama_1` ()  NO SQL
SELECT tbl_buku.*,tbl_member.*,pustakawan.*,peminjama_1.* FROM
tbl_buku,tbl_member,pustakawan,peminjama_1 WHERE
tbl_buku.buku_id=peminjama_1.buku_id AND 
tbl_member.member_id=peminjama_1.member_id AND
pustakawan.pustakawan_id=peminjama_1.pustakawan_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `tampil_pustakawan` ()  NO SQL
SELECT pustakawan$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_buku` (IN `buku_id` INT(11), IN `buku_judul` VARCHAR(100), IN `buku_tgl` DATE, IN `buku_jumlah` INT(10))  NO SQL
UPDATE tbl_buku SET 
tbl_buku.buku_judul=buku_judul,
tbl_buku.buku_tgl_stok=buku_tgl,
tbl_buku.buku_jumlah=buku_jumlah
WHERE tbl_buku.buku_id=buku_id$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_member` (IN `member_id` INT(11), IN `member_nama` VARCHAR(50), IN `member_jenis_kelamin` ENUM('L','P'), IN `member_tempat_lahir` VARCHAR(100), IN `member_tgl_lahir` DATE, IN `member_hp` CHAR(13))  NO SQL
UPDATE tbl_member SET 
tbl_member.member_nama=namamember,
tbl_member.member_jenis=jenismember,
tbl_member.member_tempat=tempatmember,
tbl_member.member_tgl=tglmember,
tbl_member.member_hp=hpmember
WHERE tbl_member.member_id=idmember$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_peminjaman_1` (IN `id_pinjam` MEDIUMINT(11), IN `tgl_pinjam` DATE, IN `jumlah_pinjam` INT(3), IN `tgl_kembali` DATE, IN `jumlah_kembali` INT(3), IN `pinjam_lama` INT(2), IN `terlambat_pinjam` INT(2), IN `denda_pinjam` BIGINT(20), IN `id_buku` INT(11), IN `id_member` INT(11), IN `id_pustakawan` INT(11))  NO SQL
UPDATE peminjama_1 SET
peminjama_1.pinjam_tgl=tgl_pinjam,
peminjama_1.pinjam_jumlah=jumlah_pinjam,
peminjama_1.pinjam_kembali_tgl=tgl_kembali,
peminjama_1.pinjam__kembali_jumlah=jumlah_kembali,
peminjama_1.pinjam_lama_pinjam=pinjam_lama,
peminjama_1.pinjam_terlambat=terlambat_pinjam,
peminjama_1.pinjam_denda=denda_pinjam,
peminjama_1.buku_id=id_buku,
peminjama_1.member_id=id_member,
peminjama_1.pustakawan_id=id_pustakawan
WHERE peminjama_1.pinjam_id=id_pinjam$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `update_pustakawan` (IN `pustakawan_id` INT(11), IN `pustakawan_nama` VARCHAR(50), IN `pustakawan_jenis` ENUM('L','P'), IN `pustakawan_alamat` TEXT, IN `pustakawan_hp` CHAR(13))  NO SQL
UPDATE pustakawan SET
pustakawan.pustakawan_nama=pustakawan_nama,
pustakawan.pustakawan_jenis=pustakawan_jenis,
pustakawan.pustakawan_alamat=pustakawan_alamat,
pustakawan.pustakawan_hp=pustakawan_hp
WHERE pustakawan.pustakawan_id=pustakawan_id$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `peminjama_1`
--

CREATE TABLE `peminjama_1` (
  `pinjam_id` mediumint(11) NOT NULL,
  `pinjam_tgl` date NOT NULL,
  `pinjam_jumlah` int(3) NOT NULL,
  `pinjam_kembali_tgl` date NOT NULL,
  `pinjam__kembali_jumlah` int(3) NOT NULL,
  `pinjam_lama_pinjam` int(2) NOT NULL,
  `pinjam_terlambat` int(2) NOT NULL,
  `pinjam_denda` bigint(20) NOT NULL,
  `buku_id` int(11) NOT NULL,
  `member_id` int(11) NOT NULL,
  `pustakawan_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pustakawan`
--

CREATE TABLE `pustakawan` (
  `pustakawan_id` int(11) NOT NULL,
  `pustakawan_nama` varchar(50) NOT NULL,
  `pustakawan_jenis` enum('L','P') NOT NULL,
  `pustakawan_alamat` text NOT NULL,
  `pustakawan_hp` char(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_buku`
--

CREATE TABLE `tbl_buku` (
  `buku_id` int(11) NOT NULL,
  `buku_judul` varchar(100) NOT NULL,
  `buku_tgl_stok` date NOT NULL,
  `buku_jumlah` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_member`
--

CREATE TABLE `tbl_member` (
  `member_id` int(11) NOT NULL,
  `member_nama` varchar(50) NOT NULL,
  `member_jenis_kelamin` enum('L','P') NOT NULL,
  `member_tempat_lahir` varchar(100) NOT NULL,
  `member_tgl_lahir` date NOT NULL,
  `member_hp` char(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_peminjaman`
--

CREATE TABLE `tbl_peminjaman` (
  `pinjam` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `peminjama_1`
--
ALTER TABLE `peminjama_1`
  ADD PRIMARY KEY (`pinjam_id`),
  ADD KEY `buku_id` (`buku_id`),
  ADD KEY `member_id` (`member_id`),
  ADD KEY `pustakawan_id` (`pustakawan_id`);

--
-- Indexes for table `pustakawan`
--
ALTER TABLE `pustakawan`
  ADD PRIMARY KEY (`pustakawan_id`);

--
-- Indexes for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  ADD PRIMARY KEY (`buku_id`);

--
-- Indexes for table `tbl_member`
--
ALTER TABLE `tbl_member`
  ADD PRIMARY KEY (`member_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `peminjama_1`
--
ALTER TABLE `peminjama_1`
  MODIFY `pinjam_id` mediumint(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pustakawan`
--
ALTER TABLE `pustakawan`
  MODIFY `pustakawan_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_buku`
--
ALTER TABLE `tbl_buku`
  MODIFY `buku_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_member`
--
ALTER TABLE `tbl_member`
  MODIFY `member_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `peminjama_1`
--
ALTER TABLE `peminjama_1`
  ADD CONSTRAINT `peminjama_1_ibfk_1` FOREIGN KEY (`member_id`) REFERENCES `tbl_member` (`member_id`),
  ADD CONSTRAINT `peminjama_1_ibfk_2` FOREIGN KEY (`buku_id`) REFERENCES `tbl_buku` (`buku_id`),
  ADD CONSTRAINT `peminjama_1_ibfk_3` FOREIGN KEY (`pustakawan_id`) REFERENCES `pustakawan` (`pustakawan_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
